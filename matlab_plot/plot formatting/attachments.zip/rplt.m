figure
P=PlotLayout(gcf,ones(1,8),ones(1,8));

pos=RepositionPlotLayout(P,2:4,2:3)