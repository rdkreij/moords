function [ pos ] = RepositionPlotLayout( P , rows , cols )

dc=diff(cols)==1;
if ~all(dc) && ~isempty(dc)
    error
end
dr=diff(rows)==1;
if ~all(dc) && ~isempty(dc)
	error
end

LHX=P{rows(end),cols(1)}(1);
LHY=P{rows(end),cols(1)}(2);

RHX=P{rows(1),cols(end)}(1) + P{rows(1),cols(end)}(3);
RHY=P{rows(1),cols(end)}(2)   + P{rows(1),cols(end)}(4);

pos = [LHX LHY RHX-LHX RHY-LHY];

end

